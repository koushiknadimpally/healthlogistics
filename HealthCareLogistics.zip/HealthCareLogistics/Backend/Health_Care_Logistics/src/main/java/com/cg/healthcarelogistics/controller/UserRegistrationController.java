package com.cg.healthcarelogistics.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.healthcarelogistics.dto.UserRegistration;
import com.cg.healthcarelogistics.service.UserRegistrationService;

@RestController
@RequestMapping("/userregister")
@CrossOrigin(origins="http://localhost:4200")
public class UserRegistrationController {
	@Autowired
	UserRegistrationService userRegistrationService;
	
	//method for validating the user credentials based on mobile no and password
	@GetMapping("/validatemobile/{mob}/{password}")
	public boolean validateMobile(@PathVariable("mob") Long mobile,@PathVariable("password")String password) {
		return userRegistrationService.validateUserLogin(mobile,password);
	}
	//method for adding the new user
	@PostMapping("/adduuser")
	public UserRegistration addUser(@RequestBody UserRegistration user) {
			return userRegistrationService.addUser(user);
	}
	//method for getting the user role details
	@GetMapping("/getroledetails/{mobile}/{password}")
	public Integer getRoleDetails(@PathVariable("mobile") Long mob,@PathVariable("password") String pwd) {
		String role=userRegistrationService.getDetailsBasedOnRole(mob, pwd);
				if(role.equalsIgnoreCase("manager")){
			return 1;
			
		}
		else if(role.equalsIgnoreCase("technician")) {
			return 2;
			
		}
		
			
		else if(role.equalsIgnoreCase("customer")){
			return 3;
		}
				return 4;
	}
		
		
		
	//method for fetching all the user details
	@GetMapping("/getalluser")
	public List<UserRegistration> getAllUserDetails(){
		return userRegistrationService.getAllUserDetails();
	}
	
	//method for fetching the user details based on the mobile number 
	@GetMapping("/getUserMobile/{mobile}")
	public UserRegistration getUserMobile(@PathVariable("mobile") Long mobile) {
				return userRegistrationService.getUserMobile(mobile);
	}
	//method for setting the user mail to the technician mail
	@PostMapping("/booking/{umail}/{tmail}")
	public String booking(@PathVariable("umail") String umail,@PathVariable("tmail") String tmail) {
		
		int i=userRegistrationService.booking(umail, tmail);
		if(i==1) {
			return "success";
		}
		else {
			return "unsuccess";
		}
	}
	
	@GetMapping("/booking/{umail}/{tmail}")
	public Integer booking1(@PathVariable("umail") String umail,@PathVariable String tmail) {
		return userRegistrationService.booking(umail, tmail);
		}
	//method for getting the user details based on particular technician
	@GetMapping("/getdetails/{tmail}")
		public List<UserRegistration> getdetails(@PathVariable("tmail") String tmail){
			return userRegistrationService.getDetails(tmail);
		}
	}



package com.cg.healthcarelogistics.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;


import com.cg.healthcarelogistics.dto.Tests;
import com.cg.healthcarelogistics.dto.UserRegistration;

import ch.qos.logback.core.net.SyslogOutputStream;

@Repository
public class TestsDaoImpl implements  TestsDao{
	Integer totalPrice=0;
@Autowired
MongoTemplate mongoTemplate;
@Autowired
UserRegistrationDao userRegistrationDao;
	@Override
	public Tests addTest(Tests test) {
		return mongoTemplate.insert(test);
	}

	@Override
	public void updateTest(Long testId, Integer price) {
			List<Tests> details=mongoTemplate.findAll(Tests.class);
		for(Tests testDetails:details) {
			if(testDetails.getTestId().equals(testId)) {
				testDetails.setTestPrice(price);
				mongoTemplate.save(testDetails);
			}
		}
		
	}

	@Override
	public List<Tests> getAllTests() {
			return mongoTemplate.findAll(Tests.class);
	}

	@Override
	public void deleteTest(Long testId) {
	List<Tests> data=mongoTemplate.findAll(Tests.class);
	for(Tests deletetests:data) {
		if(deletetests.getTestId().equals(testId)) {
			mongoTemplate.remove(deletetests);
		}
	}
		
	}

}

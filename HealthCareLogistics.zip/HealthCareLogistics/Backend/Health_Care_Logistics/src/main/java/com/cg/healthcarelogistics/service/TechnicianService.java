package com.cg.healthcarelogistics.service;

import java.util.List;

import com.cg.healthcarelogistics.dto.TechnicianRole;
import com.cg.healthcarelogistics.dto.Tests;
import com.cg.healthcarelogistics.dto.UserRegistration;

public interface TechnicianService {
	public TechnicianRole addTechnician(TechnicianRole managerRole);
	public List<TechnicianRole> getAllTechnician();
	public void updateTechnician(Long mobile,Integer salary,Integer experience);
	public void deleteTechnician(Long mobileNo);
	public boolean getTechnicianDetails(Long mobile,String password);
	
}

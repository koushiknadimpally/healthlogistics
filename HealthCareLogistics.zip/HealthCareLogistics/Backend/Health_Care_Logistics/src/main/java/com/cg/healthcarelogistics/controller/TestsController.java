package com.cg.healthcarelogistics.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.healthcarelogistics.dto.Tests;
import com.cg.healthcarelogistics.dto.UserRegistration;
import com.cg.healthcarelogistics.service.TestsService;

@RestController
@RequestMapping("/technicianrole")
@CrossOrigin(origins="http://localhost:4200")

public class TestsController {
	
	@Autowired
	TestsService technicianRoleService;
	//method for adding new tests
	@PostMapping("/addtests")
	public Tests addTests(@RequestBody Tests testDetails) {
		
		return technicianRoleService.addTest(testDetails);
	}
	//method for updating the tests based on the testId and testprice
	@PutMapping("/updatetests/{testId}/{price}")
	public void updateTests(@PathVariable("testId") Long testId,@PathVariable("price") Integer testPrice ) {
		
		technicianRoleService.updateTest(testId, testPrice);
	}
	
	//method for fetching all the tests
	@GetMapping("/getalltests")
	public List<Tests> getAllTests(){
		
		return technicianRoleService.getAllTests();
	}
	//method for deleting the tests based on the testId
		@DeleteMapping("/deletetests/{id}")
	public void deleteTests(@PathVariable("id") Long id) {
		technicianRoleService.deleteTest(id);
}
}

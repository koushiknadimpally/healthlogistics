package com.cg.healthcarelogistics.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.healthcarelogistics.dto.TechnicianRole;
import com.cg.healthcarelogistics.dto.Tests;
import com.cg.healthcarelogistics.dto.UserRegistration;
import com.cg.healthcarelogistics.service.TechnicianService;

@RestController
@RequestMapping("/managercontrol")
@CrossOrigin(origins="http://localhost:4200")
public class TechnicianController {
	@Autowired
	TechnicianService managerService;
	
	//method for adding the new technician
	@PostMapping("/addtechnician")
	public TechnicianRole addTechnician(@RequestBody TechnicianRole managerRole) {
		return managerService.addTechnician(managerRole);
		
	}
	//method for fetching all the technician details
	@GetMapping("/getalltechnician")
	public List<TechnicianRole> getAllTechnician(){
		return managerService.getAllTechnician();	
	}
	
	//method for updating the technician salary and experience based on the mobile no
	@PutMapping("/updatetechnician/{mobileNo}/{salary}/{experience}")
	public void updateTechnician(@PathVariable("mobileNo") Long mobile,@PathVariable("salary")Integer salary,@PathVariable("experience")Integer experience) {
			managerService.updateTechnician(mobile, salary, experience);
	}
	
	//method for deleting the technician based on the mobile no
	@DeleteMapping("/deletetechnician/{mobileNo}")
	public void deleteTechnician(@PathVariable("mobileNo") Long mobile) {
		managerService.deleteTechnician(mobile);
	}
	
	@GetMapping("/getroledetails/{mobile}/{password}")
	public boolean getTechnicianDetails(@PathVariable("mobile") Long mob,@PathVariable("password") String pwd) {
		boolean validUser=managerService.getTechnicianDetails(mob, pwd);
	
		if(validUser==true) {
			return true;
		}
		
			
		return false;
	}
		
}

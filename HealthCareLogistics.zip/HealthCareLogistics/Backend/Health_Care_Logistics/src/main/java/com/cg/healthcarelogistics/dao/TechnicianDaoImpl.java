package com.cg.healthcarelogistics.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.cg.healthcarelogistics.dto.TechnicianRole;
import com.cg.healthcarelogistics.dto.Tests;
import com.cg.healthcarelogistics.dto.UserRegistration;
import com.mongodb.Mongo;

@Repository
public class TechnicianDaoImpl implements TechnicianDao {
	@Autowired
	MongoTemplate mongotemplate;

	@Override
	public TechnicianRole addTechnician(TechnicianRole managerRole) {
		// TODO Auto-generated method stub
		return mongotemplate.insert(managerRole);
	}

	@Override
	public List<TechnicianRole> getAllTechnician() {
		// TODO Auto-generated method stub
		return mongotemplate.findAll(TechnicianRole.class) ;
	}

	@Override
	public void updateTechnician(Long mobile,Integer salary, Integer experience) {
		// TODO Auto-generated method stub
		List<TechnicianRole> technicianDetails=mongotemplate.findAll(TechnicianRole.class);
		for(TechnicianRole data:technicianDetails) {
			if(data.getMobileNo().equals(mobile)) {
				data.setSalary(salary);
				data.setExperience(experience);
				mongotemplate.save(data);
			}
		}
		
	}

	@Override
	public void deleteTechnician(Long mobileNo) {
		// TODO Auto-generated method stub
		List<TechnicianRole> data3=mongotemplate.findAll(TechnicianRole.class);
		for(TechnicianRole data4:data3) {
			if(data4.getMobileNo().equals(mobileNo)) {
				mongotemplate.remove(data4);
			}
		}
		
		
	}
	@Override
	public boolean getTechnicianDetails(Long mobile, String password) {
		// TODO Auto-generated method stub
		boolean valid=false;
		
		List<TechnicianRole> details=mongotemplate.findAll(TechnicianRole.class);
		for(TechnicianRole technicianDetails:details) {
		if(technicianDetails.getMobileNo().equals(mobile)) {
				if(technicianDetails.getPassword().equals(password)) {
				valid=true;
				
				}
			}
		}
		return valid;
	}
	
	@Override
	public List<UserRegistration> getBookedUsers(Long techId) {
		// TODO Auto-generated method stub
		List<TechnicianRole> details=mongotemplate.findAll(TechnicianRole.class);
		List<UserRegistration> users=new ArrayList<>();
		for(TechnicianRole technicianCustomer:details) {
			if(technicianCustomer.getMobileNo().equals(techId)) {
				//users.add(technicianCustomer.getCustomerMobileNo());
				List<TechnicianRole> bookedUserDetails=(List<TechnicianRole>) mongotemplate.findById(techId, TechnicianRole.class);
							
			
			}
		}
		return users;
	}

}

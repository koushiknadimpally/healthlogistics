import { Component, OnInit } from '@angular/core';
import { HealthService } from '../health.service';

@Component({
  selector: 'app-managerdeletetechnician',
  templateUrl: './managerdeletetechnician.component.html',
  styleUrls: ['./managerdeletetechnician.component.css']
})
export class ManagerdeletetechnicianComponent implements OnInit {
data:any=[];
result:any=[];
  constructor(private service:HealthService) { }
  //code for deleting the particular technician
  deleteTechnician(mobile:any){
  
    console.log("in delete technician ts file"+mobile);
    let index=this.data.indexOf(mobile);
    this.data.splice(index,1);
      this.service.deleteTechnician(mobile).subscribe();
    
    }
    //code for displaying all the technician details
  getAllTechnician()
  {
    this.service.getAllTechnician().subscribe(result=>{this.data=result;
      console.log("in manager delete technician"+this.data);
    
  })
  }
  ngOnInit() {
    this.service.getAllTechnician().subscribe(result=>{this.data=result;
      console.log("data"+this.data)});
  
  }

}

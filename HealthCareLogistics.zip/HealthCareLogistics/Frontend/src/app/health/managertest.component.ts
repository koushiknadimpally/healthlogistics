import { Component, OnInit } from '@angular/core';
import { HealthService } from '../health.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-managertest',
  templateUrl: './managertest.component.html',
  styleUrls: ['./managertest.component.css']
})
export class ManagertestComponent implements OnInit {

  constructor(private service:HealthService,private router:Router) { }
  model:any={};
  result:boolean=false;
  //method for adding new tests
  addTest()
  {    
    console.log("in ts file"+this.model)
    this.result=true;
    
    this.service.addTest(this.model).subscribe();
  }
  //method for updating the tests
  updateTest()
  {
    this.router.navigate(['/updatetests'])
  }

  ngOnInit() {
  }

}

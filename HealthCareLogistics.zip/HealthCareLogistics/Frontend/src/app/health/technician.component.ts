import { Component, OnInit } from '@angular/core';
import { HealthService } from '../health.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-technician',
  templateUrl: './technician.component.html',
  styleUrls: ['./technician.component.css']
})
export class TechnicianComponent implements OnInit {
  mobile:number;
password:any;
email:any;
result:any;
message:boolean=false;
  constructor(private service:HealthService,private router:Router) { }
  //method for validating the email and password for the technician
  check(mobile,password,email){
    this.service.getTechnicianDetails(mobile,password).subscribe(data=>{
      this.result=data;
      if(this.result==true)
      {
       
        this.service.technicianMail=email;
       
        this.router.navigate(['/technicianacceptreject'])
      }
     
      else {
        this.message=true;
      }

    });
  }


  
  ngOnInit() {
  }

}

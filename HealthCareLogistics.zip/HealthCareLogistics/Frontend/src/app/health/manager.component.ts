import { Component, OnInit } from '@angular/core';
import { HealthService } from '../health.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-manager',
  templateUrl: './manager.component.html',
  styleUrls: ['./manager.component.css']
})
export class ManagerComponent implements OnInit {
mobile:number;
password:any;
email:any;
result:any;
data:any;
message:boolean=false;
  constructor(private service:HealthService,private router:Router) { }
  //validating the mobileno and password for manager login
  check(mobile,password){
    console.log("mobile and password is"+mobile+password)
    this.service.getAllRoleDetails(mobile,password).subscribe(data=>{
      this.result=data;
      if(this.result==1)
      {
        this.router.navigate(['/manageroperations'])
      }
     
      else {
        this.message=true;
      }

    });
  }

  ngOnInit() {

  }

}

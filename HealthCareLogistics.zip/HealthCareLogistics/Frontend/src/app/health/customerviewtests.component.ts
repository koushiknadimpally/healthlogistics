import { Component, OnInit } from '@angular/core';
import { HealthService } from '../health.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customerviewtests',
  templateUrl: './customerviewtests.component.html',
  styleUrls: ['./customerviewtests.component.css']
})
export class CustomerviewtestsComponent implements OnInit {
data:any=[];
  constructor(private service:HealthService,private router:Router) { }
  result:any=[];
  message:boolean=false;
  AddTests(){
    this.message=true;
  }
  ngOnInit() {
    this.service.getAllTests().subscribe(result=>this.data=result);

  }

}

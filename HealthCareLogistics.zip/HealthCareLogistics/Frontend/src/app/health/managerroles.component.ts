import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-managerroles',
  templateUrl: './managerroles.component.html',
  styleUrls: ['./managerroles.component.css']
})
export class ManagerrolesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

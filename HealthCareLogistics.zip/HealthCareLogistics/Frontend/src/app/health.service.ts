import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Observable, Subject, concat} from 'node_modules/rxjs';


@Injectable({
  providedIn: 'root'
})
export class HealthService {
  currentTestId:number=0;
  
  
  private _resultSource=new Subject<object>();
  result$=this._resultSource.asObservable();
  private _resultSource1=new Subject<object>();
  result1$=this._resultSource1.asObservable();
currentUser:number=0;
currentUserMailId:String="";
technicianMail:String="";
acceptmessage:string="";
  clickstatus:boolean;
  data3:any=[];
  data4:any=[];
  customers: Observable<Object>;
  result:any;
  constructor(private http:HttpClient) { }
  sendData(data){
    
    this._resultSource.next(data);
    
  }
  gettingData(data){
  
    this._resultSource1.next(data);
  }
  addUserRegister(data:any){
  
    let userinput={"mobileNo":data.mobile,
    "userName":data.username,
     "gender":data.gender,
     "email":data.email,
    "role":data.role,
   "password":data.password,
   "dob":data.dob
   
}   
   
    return this.http.post("http://localhost:9927/userregister/adduuser",userinput);
  }

  checkMobile(mobile:number,pwd:String){
  
    return this.http.get("http://localhost:9927/userregister/validatemobile/"+mobile+"/"+pwd);

  }

  acceptingbooking(usermail:string,clickingstatus:boolean){
    this.acceptmessage=usermail;
    this.clickstatus=clickingstatus;
    

  }
  addTest(data:any){
    let input={"testId":data.id,
    "testName":data.name,
    "testPrice":data.price,
    "testDescription":data.desc}
   
    return this.http.post("http://localhost:9927/technicianrole/addtests",input);

};

deleteTests(data:any){

  return this.http.delete("http://localhost:9927/technicianrole/deletetests/"+data);
}
addTechnician(data:any){
  let input1={
    "mobileNo":data.mobile,
    "technicianName":data.name,
    "salary":data.salary,
    "gender":data.gender,
    "experience":data.experience,
    "technicianDescription":data.desc,
    "password":data.password,
    "technicianEmail":data.email
  }
 
  return this.http.post("http://localhost:9927/managercontrol/addtechnician",input1);
}
getAllTechnician()
{
  return this.http.get("http://localhost:9927/managercontrol/getalltechnician");
}
deleteTechnician(data:any)
{
return this.http.delete("http://localhost:9927/managercontrol/deletetechnician/"+data)
}

getAllTests(){
  return this.http.get("http://localhost:9927/technicianrole/getalltests");
}
getAllRoleDetails(mobile:number,password:string){
 
  return this.http.get("http://localhost:9927/userregister/getroledetails/"+mobile+"/"+password);
}

getTechnicianDetails(mobile:number,password:string){
 
  return this.http.get("http://localhost:9927/managercontrol/getroledetails/"+mobile+"/"+password);

}
getMobile(mobile){
 
 this.http.get("http://localhost:9927/userregister/getUserMobile/"+mobile);
 this.data3 = this.http.get("http://localhost:9927/userregister/getUserMobile/"+mobile);
 
  return this.data3;
}


setDetails(data)
{
 this.data4=data;
 
}
getAllDetails(){
  
  return this.data4;
}
updateTests(id:number,price:number){
  
 return this.http.put("http://localhost:9927/technicianrole/updatetests/"+id+"/"+price,+id);
}
addBooking(umail: String,tmail: String) {
  
  return this.http.get("http://localhost:9927/userregister/booking/"+umail+"/"+tmail);
   
}
getBookedUsers(technicianMail: String) {
 
  return this.http.get("http://localhost:9927/userregister/getdetails/"+technicianMail);

}
}

